MEXICO ROOM WEBSITE UPDATE

Files:
- index.html (updated website with the Mexico room added)
- mexico-side-view.jpg (first uploaded room photo)
- mexico-front-view.jpg (second uploaded room photo)

For GitHub:
1. Upload index.html to the same folder as your current website index.html, replacing the old index.html.
2. Upload both Mexico JPG images to that same folder (usually the repository root).
3. Keep the image filenames exactly as written:
   mexico-side-view.jpg
   mexico-front-view.jpg

The existing website uses other room photos such as green-1.jpg and bath-1.jpg in the same folder, so these two files should also be in that folder.
